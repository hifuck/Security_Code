# Perun

## 如何开始使用

[开始使用](https://github.com/WyAtu/Perun/blob/master/doc/how2start.md)

## 支持的Vuln模块

[支持的Vuln模块](https://github.com/WyAtu/Perun/blob/master/doc/aboutvuln.md#%E6%94%AF%E6%8C%81%E7%9A%84vuln%E6%A8%A1%E5%9D%97)

## 自定义Vuln模块

[编写新的自定义Vuln模块](https://github.com/WyAtu/Perun/blob/master/doc/aboutvuln.md#%E8%87%AA%E5%AE%9A%E4%B9%89vuln%E6%A8%A1%E5%9D%97)

**欢迎编写并提交更多自定义模块，直接pr或者发到邮箱wyatu[@]foxmail.com**

## 如何打包

[打包Perun二进制文件](https://github.com/WyAtu/Perun/tree/master/doc/package2exe#%E6%89%93%E5%8C%85perun%E4%BA%8C%E8%BF%9B%E5%88%B6%E6%96%87%E4%BB%B6)