#!/usr/bin/env python
# coding=utf-8

"""
Copyright (c) 2014 BlackYe.
Mail:363612366@qq.com
"""

def main():
    pass


if __name__ == '__main__':
    main()

