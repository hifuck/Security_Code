#!/usr/bin/env python
# coding=utf-8


################################
#send email setting
MAIL_HOST = "smtp.163.com"
MAIL_PORT = "25"
MAIL_USER = ""
MAIL_PASS = ""
MAIL_POSTFIX = "163.com"

###############################
#receive email setting
MAILTO_LIST = ["yourmail@qq.com"]
