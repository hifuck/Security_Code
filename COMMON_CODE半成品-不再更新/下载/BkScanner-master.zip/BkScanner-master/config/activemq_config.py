#!/usr/bin/env python
# coding=utf-8

MASTER_AQ_HOST = '127.0.0.1'
MASTER_AQ_HOST_PORT = 61613
MASTER_AQ_HOST_VER = 'linux'


SUBSCRIBE_DESC = 'scan_info'
