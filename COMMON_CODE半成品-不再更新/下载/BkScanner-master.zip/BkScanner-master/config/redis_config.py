#!/usr/bin/env python
# coding=utf-8

REDIS_HOST = '127.0.0.1'
REDIS_HOST_PORT = 6379
REDIS_VER = 'linux'

REDIS_DB = 1


WEBSCAN_KEY   = 'webpathscan'
PORTCRACK_KEY = 'portcrack'
SYSVUL_KEY    = 'sysvul'
WEBAPP_KEY    = 'webappvul'   #web框架漏洞插件