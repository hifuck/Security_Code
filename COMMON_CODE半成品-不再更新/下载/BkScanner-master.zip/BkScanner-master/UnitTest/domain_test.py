#!/usr/bin/evn python
#-*- coding:utf-8 -*-

__author__ = 'zhangqiang'




if __name__ == '__main__':
    domain = base.BaseDomain()
    #print domain._baccess('http://www.baidu.com')
    print domain._baccess('10.1.14.245', 1)